Double-click the following executables to install:

* RAVE Bundled Installer: installs R, RStudio, xcode command-line tools, RAVE
* Update Scripts: Update RAVE commands
